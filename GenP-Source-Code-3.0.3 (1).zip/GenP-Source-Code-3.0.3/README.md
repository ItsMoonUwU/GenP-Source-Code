# GenP 3.0.3 + Source Code
Unmodified copy of the final **GenP 3.0.3 release + source code** made avaliable by uncia on CGPersia Forums ([original private release](http://forum.cgpersia.com/f13/adobe-2019-2021-uncia-patch-windows-updated-3-13-21-a-194783/index40.html#post1853868)). For&nbsp;research&nbsp;purposes.

The source code are the .au3 files with which you can build GenP using SciTE which you can also download from [here](https://www.autoitscript.com/site/autoit-script-editor/downloads/).

Since uncia is retired now (check [this post](https://www.reddit.com/r/GenP/comments/11irrgg/uncia_has_gone_goodbye_uncia/) for more info) and GenP has become open source, there won't be any new "official" releases, but rather versions made by individuals or communities, that may or may not contain malaware.

Two of those community versions which will become the most popular ones are the "CGP Community Verison" which can be found on their private forum [CGPersia Forums](https://forum.cgpersia.com/f13/adobe-2019-2021-uncia-patch-windows-updated-3-13-21-a-194783/), and the "r/GenP Community Version" which is still being developed (not released yet) by a team of people on [r/GenP](https://www.reddit.com/r/GenP/) who can also be found on their [Discord server](https://discord.com/invite/X9ZuegSM4N), which will get released as GenP 3.3.5.

From now on be cautious from where you download newer GenP versions cause there will be a lot of other custom versions made by individuals which may contain malaware. Just download from trusted sites like [r/GenP](https://www.reddit.com/r/GenP/wiki/redditgenpguides/#wiki_.1F921_guide_.232_-_dummy_guide_for_first_timers_genp_.28cc_.2B_genp.29).

Check this [FAQ](https://www.reddit.com/r/GenP/wiki/faq/) for more info regarding GenP.

Note that despite uncia being gone, GenP is still alive and in developement.
<p align="center">
  <img src="https://i.ibb.co/GMStH67/5.png" alt="GenP logo" width="300" height="auto">
</p>
